# Sgp4-Library
Library for calculating satellite positions and predicting overpasses.
Tested on an ESP8266 and ESP32.

# Credits
Original source code written by David Vallado: https://celestrak.com/software/vallado-sw.asp  
[Coordinate transformation](https://github.com/gradyh/ISS-Tracking-Pointer) ported by Grady Hillhouse. It is distributed under MIT license.
